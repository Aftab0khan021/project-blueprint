// supabase/functions/invite-staff/index.ts
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";


const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  // CORS preflight
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    /**
     * ✅ IMPORTANT
     * Supabase already authenticates the request BEFORE invoking this function.
     * We must NOT re-validate JWT manually.
     */

    const userId =
      req.headers.get("x-user-id") ||
      req.headers.get("sb-auth-user") ||
      req.headers.get("sb-auth-user-id");

    if (!userId) {
      return new Response(
        JSON.stringify({ error: "Unauthorized" }),
        {
          status: 401,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const payload = await req.json();

    // ✅ Logs now work correctly
    console.log("invite-staff called", {
      user_id: userId,
      payload,
    });

    // 🔐 Service role client (server-only, secret already set)
    const supabaseAdmin = createClient(
     import.meta.env.VITE_SUPABASE_URL,
     import.meta.env.VITE_SUPABASE_ANON_KEY
    )

    // ----------------------------------------------------
    // Existing logic (UNCHANGED)
    // ----------------------------------------------------

    // Resend invite path
    if (payload.action === "resend") {
      return new Response(
        JSON.stringify({ success: true }),
        {
          status: 200,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const { email, restaurant_id, role } = payload;

    const { data, error } =
      await supabaseAdmin.auth.admin.inviteUserByEmail(email, {
        data: {
          restaurant_id,
          role: role || "user",
        },
      });

    if (error) throw error;

    return new Response(JSON.stringify(data), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err: any) {
    return new Response(
      JSON.stringify({ error: err.message }),
      {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});
